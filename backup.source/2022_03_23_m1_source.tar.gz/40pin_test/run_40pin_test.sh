#!/bin/bash

echo odroid | sudo -S ./40pin_test
