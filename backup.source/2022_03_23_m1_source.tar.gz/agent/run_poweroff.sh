#!/bin/bash

echo odroid | sudo -S poweroff
