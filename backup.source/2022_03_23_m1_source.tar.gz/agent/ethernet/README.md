1. check eth node
2. check gigabit
3. iperf test
