from utils.log import init_logger

LOG = init_logger('eth', 'debug')

PATH_ETH0 = '/sys/class/net/eth0/speed'
PATH_MAC_CFG = '/root/sbc-jig/target/mac_uuid/EF8153B.cfg'
PATH_MAC_CFG2 = '/root/sbc-jig/target/mac_uuid/EF8153C.cfg'
PATH_MAC = '/root/sbc-jig/target/mac_uuid/'
