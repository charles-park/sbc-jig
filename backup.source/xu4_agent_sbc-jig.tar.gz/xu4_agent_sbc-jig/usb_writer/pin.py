import gpiodcxx as gpiod

class Pin():
    def __init__(self, pin_num, line_name, config=None):
        self.pin_num = pin_num
        self.line_name = line_name
        self.config = config

        if line_name == "":
            return
        self.gpio = gpiod.find_line(self.line_name)
        try:
            self.gpio.request(self.config)
        except RuntimeError as e:
            print(f'pin{self.pin_num}:{self.line_name} {e}')

    def set_value(self, val):
        try:
            self.gpio.set_value(val)
        except RuntimeError as e:
            print(f'pin{self.pin_num}:{self.line_name} {e}')
    def get_value(self):
        try:
            return self.gpio.get_value()
        except RuntimeError as e:
            print(f'pin{self.pin_num}:{self.line_name} {e}')

