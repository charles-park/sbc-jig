from uart import Uart
from adc import ADC
from odroid_factory_api import API_MANAGER
from utils.log import init_logger
import asyncio
from asyncio import ensure_future as aef
from board import XU4
from copy import deepcopy
import sys, os, time
import cups
from datetime import datetime
from pytz import timezone

LOG = init_logger('', testing_mode='info')

from kivy.uix.boxlayout import BoxLayout
from kivy.app import App
from kivy.config import Config
from kivy.properties import ObjectProperty
from kivy.lang import Builder

Config.set('graphics', 'fullscreen', 'auto')
Config.set('graphics', 'borderless', 0)
Config.set('graphics', 'allow_screensaver', 0)

os.environ['DISPLAY'] = ":0.0"

FORUM = 'forum.odroid.com'

BOARD = 'xu4'
UI_KV = f'{BOARD}.kv'


class AgentApp(App):
    def build(self):
        Builder.load_file(UI_KV)
        av = AgentView()
        aef(av.init())
        return av

    def app_func(self):
        async def run_wrapper():
            await self.async_run(async_lib='asyncio')
        return asyncio.gather(run_wrapper())

class AgentView(BoxLayout):
    time = 0
    start_time = True
    async def init(self):
        self.agent = []
        for i in range(2):
            self.agent.append(Agent(i))
            await self.agent[i].init_tasks()
            self.ids[f'ch{i}'].name.text = f'CH{i}'
            self.ids[f'ch{i}'].init(self.agent[i])
            aef(self.update(self.ids[f'ch{i}']))

        aef(self.monitor_ip())
        aef(self.timer())
        #aef(self.monitor_counts())
        aef(self.monitor_dates())

    async def update(self, channel):
        while True:
            channel.update()
            await asyncio.sleep(0.3)

    async def timer(self):
        while True:
            if self.start_time:
                self.time += 1
                d = datetime.fromtimestamp(self.time)
                self.ids['time'].text = d.strftime("%H:%M:%S")
                self.ids['time1'].text = d.strftime("%H:%M:%S")
            await asyncio.sleep(1)

    def reset_timer(self):
        self.time = 0
        d = datetime.fromtimestamp(self.time)
        self.ids['time'].text = d.strftime("%H:%M:%S")
        self.ids['time1'].text = d.strftime("%H:%M:%S")

    def start_timer(self):
        start_color = [(1, 0, 0, 0.8), (0, 1, 0, 0.8)]
        self.start_time = not self.start_time
        self.ids['time'].background_color = start_color[self.start_time]
        self.ids['time1'].background_color = start_color[self.start_time]

    async def monitor_dates(self):
        while True:
            x = datetime.now(timezone('Asia/Seoul'))
            self.ids['date'].text = x.strftime("%Y-%m-%d %H:%M")
            await asyncio.sleep(1)

    async def monitor_counts(self):
        api_manager = API_MANAGER(board=BOARD)
        while True:
            cnt = await api_manager.get_counts(
                    filter='today')
            self.ids['cnt_today'].text = str(cnt)
            await asyncio.sleep(10)

    async def monitor_ip(self):
        ipaddr = None
        while True:
            _ipaddr = await self.get_ipaddr()
            if ipaddr != _ipaddr:
                ipaddr = _ipaddr
                if ipaddr.startswith('192.168'):
                    self.ids['ipaddr'].background_color = (0, 1, 0, 0.8)
                else:
                    self.ids['ipaddr'].background_color = (1, 0, 0, 0.8)
                self.ids['ipaddr'].text = ipaddr
            await asyncio.sleep(5)

    async def get_ipaddr(self):
        ipaddr = None
        cmd = 'hostname -I'
        proc = await asyncio.create_subprocess_shell(cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        if stderr != b'':
            LOG.error(stderr)
        return stdout.decode('utf-8').rstrip()

class Channel(BoxLayout):
    def __init__(self, **kwargs):
        self.agent = None
        self.items = None
        super(Channel, self).__init__(**kwargs)

    def init(self, agent):
        self.agent = agent
        self.items = self.agent.items

    def check_all(self, name):
        self.ids[name].disabled = 1
        self.agent.time = time.time()
        self.agent.init_variables()
        self.agent.seq_main = 1

    def recheck_usb3(self):
        self.agent.items['finish'].okay = 2
        aef(self.agent.task_usb3.run())

    def recheck_gpio(self):
        self.agent.items['finish'].okay = 2
        aef(self.agent.task_gpio.run())

    def poweroff(self):
        aef(self.agent.uart.send('cmd,finish'))

    def draw(self, label):
        self.items[label].update = 0
        if self.items[label].okay == 0:
            self.ids[label].background_color = (1, 0, 0, 0.8)
        elif self.items[label].okay == 1:
            self.ids[label].background_color = (0, 1, 0, 0.8)
        elif self.items[label].okay == 2:
            self.ids[label].background_color = (1, 1, 0, 0.8)
        elif self.items[label].okay == None:
            self.ids[label].background_color = (.2, .4, .7, .9)

        if self.items[label].flag_text == 1:
            self.ids[label].text = str(self.items[label].text)


    def update(self):
        if self.agent.seq_main != 0:
            self.ids['finish'].disabled = 1
            finish = self.agent.items['finish'].okay
            if finish == 1 or finish == 0:
                self.ids['finish'].disabled = 0

        if self.agent.items['onoff'].okay == 0 or self.agent.items['uart'].okay == 0:
            self.ids['finish'].disabled = 1

        for k, v in self.items.items():
            if v.update == 1:
                self.draw(k)

class Agent(XU4):
    def __init__(self, channel=0):
        super().__init__()
        self.channel = channel
        self.uart = Uart(model=self.model, channel=self.channel)
        self.adc = ADC(channel)

        self.time = time.time()

        self.ipaddr = None
        self.power_on = None

        self.seq_main = 0

    def pick_time(self):
        return round(time.time() - self.time, 2)

    def init_wait(self, item, label):
        self.items[item].okay = 0
        self.items[item].text = label
        self.items[item].update = 1

    async def wait_ack(self, item, timeout=5):
        self.items[item].req = self.pick_time()
        self.items[item].ret = None
        timeout = timeout*4
        while timeout:
            if self.items[item].ack != None:
                return 0
            timeout -= 1
            await asyncio.sleep(0.25)
        self.init_wait(item, 'No ACK')
        return -1

    async def wait_ret(self, item, timeout=10, label=None):
        timeout = timeout*4
        while timeout:
            if self.items[item].ret != None:
                return 0
            if label != None:
                tmp = label + '(' + str(int(timeout/4)) + ')'
                self.ready_item(item, tmp)
            timeout -= 1
            await asyncio.sleep(0.25)
        self.init_wait(item, 'No RET')
        return -1

    def ready_item(self, item, value=None, okay=2):
        if type(item) == str:
            if value != None:
                self.items[item].text = value
            self.items[item].okay = okay
            self.items[item].update = 1

    def fail_item(self, item, value=None):
        if type(item) == str:
            if value != None:
                self.items[item].text = value
            self.items[item].okay = 0
            self.items[item].update = 1
        LOG.info(f'FAIL item {item}')

    def okay_item(self, item, value=None):
        if type(item) == str:
            if value != None:
                self.items[item].text = value
            self.items[item].okay = 1
            self.items[item].update = 1
        LOG.info(f'OK item {item}')

    async def init_tasks(self):
        aef(self.uart.available_uart())
        aef(self.parse_msg())
        aef(self.sequence_main())
        aef(self.monitor_pwr())

    async def init_sequence(self):
        self.seq_main = 0
        self.time = time.time()
        self.init_variables()

    async def parse_usb(self, cmd, data, size):
        if cmd == 'ack':
            if data[0] == 'speed':
                self.items['usb2'].ack = self.pick_time()
        elif cmd == 'ret':
            if data[0] == 'speed':
                self.items['usb2'].ret = self.pick_time()
                self.items['usb2'].value = data[1]
                LOG.info(self.items['usb2'].value)

    async def parse_component(self, cmd, data, size):
        if cmd == 'ack':
            self.items[data[0]].ack = self.pick_time()
        elif cmd == 'ret':
            self.items[data[0]].ret = self.pick_time()
            if size > 2:
                self.items[data[0]].value = data[1:]
            elif size == 2:
                self.items[data[0]].value = data[1]

    async def parse_msg(self):
        async for cmd, data in self.uart.recv():
            if data == None:
                continue
            size = len(data)
            if size < 1:
                continue
            if cmd == 'boot' and data[0] == 'done':
                self.boot_mode = data[1]
                if self.boot_mode == 'sd':
                    await self.init_sequence()
                    self.ready_item('finish', 'SD', 2)
                    self.seq_main = 1
                elif self.boot_mode == 'emmc':
                    self.ready_item('finish', 'EMMC', 2)
                    self.seq_main = 4

            aef(self.parse_component(cmd, data, size))


async def main():
    await AgentApp().app_func()

if __name__ == "__main__":
    asyncio.run(main())
