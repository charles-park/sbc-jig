from gpio.pin import *

led_led = Pin(0x8, 0xc, "LED_RED")
led_blue = Pin(0x8, 0x8, "LED_BLUE")
led_green = Pin(0x19, 0xf, "LED_GREEN")
led_yellow = Pin(0x19, 0xb, "LED_YELLOW")

PIN_LEDS_SYS_C4 = [led_led, led_blue]
PIN_LEDS_ETH_C4 = [led_green, led_yellow]

VCC5 = Pin(0x18, 0xf, "V5")
VDDIO_AO1V8 = Pin(0x18, 0xb, "V18_AO")
VCC3V3 = Pin(0x18, 0xe, "V3")
VDDAO_3V3 = Pin(0x18, 0xa, "V3_AO")
VDDCPU = Pin(0x18, 0x9, "VDDCPU")
VDDEE = Pin(0x18, 0x8, "VDDEE")

CEC = Pin(0x19, 0xa, "CEC")
SCL = Pin(0x19, 0xe, "SCL")
SDA = Pin(0x19, 0xb, "SDA")
HPD = Pin(0x19, 0xf, "HPD")

fan_tacho = Pin(0x8, 0x8, "FAN_TACHO")
fan_pwm = Pin(0x8, 0xc, "FAN_PWM")
gpx3 = Pin(0x8, 0xb, "GPX3")
gpx17 = Pin(0x8, 0xd, "GPX17")
gpx18 = Pin(0x8, 0xa, "GPX18")
gpx5 = Pin(0x8, 0xe, "GPX5")

led_sys = Pin(0x19, 0x8, "SYS")
led_pwr = Pin(0x19, 0xc, "PWR")
led_eth_y = Pin(0x19, 0xd, "ETH_Y")
led_eth_g = Pin(0x19, 0x9, "ETH_G")
led_hdd = Pin(0x8, 0xf, "LED_HDD")

PIN_GPIOS_HC4 = [fan_tacho, fan_pwm, gpx3, gpx17, gpx18, gpx5]
#PIN_PWR_HC4 = [VCC5, VDDIO_AO1V8, VCC3V3, VDDAO_3V3, VDDCPU, VDDEE]
PIN_PWR_HC4 = [VCC3V3, VCC5]
PIN_HDMI_HC4 = [CEC, SCL, SDA, HPD]
PIN_LED_ETH = [led_eth_y, led_eth_g]
PIN_LED_SYS = [led_sys, led_pwr]
PIN_LED_HDD = [led_hdd]

class GPIO():
    def __init__(self, model):
        if model == 'HC4':
            self.gpio = PIN_GPIOS_HC4
            self.hdmi = PIN_HDMI_HC4
            self.pwrs = PIN_PWR_HC4
            self.leds_eth = PIN_LED_ETH
            self.leds_sys = PIN_LED_SYS
            self.led_hdd = PIN_LED_HDD
