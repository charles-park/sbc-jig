
class Pin:
    def __init__(self, addr, channel, label):
        self.addr = addr
        self.channel = channel
        self.label = label
