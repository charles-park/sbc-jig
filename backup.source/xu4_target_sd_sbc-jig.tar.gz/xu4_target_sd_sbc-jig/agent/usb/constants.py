from utils.log import init_logger

LOG = init_logger('usb', 'info')

