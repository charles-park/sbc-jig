import asyncio
from asyncio import ensure_future as asyncef
from serial_asyncio import open_serial_connection
from serial.serialutil import SerialException
import struct
from .constants import *

USB_R_U = '1.2'
USB_R_D = '1.3'
PLACE = [USB_R_U, USB_R_D]

class Uart():
    def __init__(self, channel=0, model=None, baudrate=9600):
        self.header = [1, model]
        self.uart = {'place': PLACE[channel], 'node': None, 'alive': -1,
                'r': None, 'w': None, 'baudrate': baudrate}
        self.channel = channel

    async def init_serial(self):
        if self.uart['node'] == None:
            return None
        try:
            self.uart['r'], self.uart['w'] = await open_serial_connection(
                    url=self.uart['node'], baudrate=self.uart['baudrate'])
        except SerialException as e:
            LOG.error(self.uart['r'], self,uart['w'])

        if (type(self.uart['r']) == asyncio.streams.StreamReader) and \
                (type(self.uart['w']) == asyncio.streams.StreamWriter):
                    self.uart['alive'] = 1
                    LOG.warn('Serial initialized')

    async def recv(self):
        while True:
            if self.uart['alive'] != 1:
                await asyncio.sleep(1)
                continue
            try:
                temp = await self.uart['r'].readuntil(b'\n')
                LOG.debug(f'msg : {temp}')
                header = struct.unpack('!B4s2s', temp[:7])
                size = int(header[2].decode('utf-8').rstrip('\x00'))
                msg = struct.unpack(f'!{size}s', temp[7:7+size])
                yield await self.check_msg_header(header[0], header[1], msg[0])
            except SerialException as e:
                LOG.error(f"serial {self.uart['node']} connection closed")
                self.uart['alive'] = 0
                self.uart['node'] = None
            except struct.error as e:
                LOG.debug(f'struct error {e}')
            except ValueError as e:
                LOG.debug(f'ValueError {e}')
            await asyncio.sleep(0.2)

    async def check_msg_header(self, ver, board, msg):
        if ver != 1:
            return None, None
        temp = msg.decode('utf-8').rstrip().split(',')
        LOG_RECEIVE.debug(f'ch{self.channel} : {temp}')
        cmd = temp[0]
        data = temp[1:]
        return cmd, data

    async def get_tty(self):
        cmd = 'ls ' + PATH_DEVICES + self.uart['place'] + ':*/ | grep ttyUSB*'
        proc = await asyncio.create_subprocess_shell(cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
        stdout = await proc.communicate()
        usb = stdout[0].decode().rstrip()
        if usb == '':
            self.uart['node'] = None
            self.uart['alive'] = 0
        elif usb.startswith('ttyUSB'):
            self.uart['node'] = f'/dev/{usb}'

    async def available_uart(self):
        while True:
            if self.uart['alive'] != 1:
                asyncef(self.get_tty())
                asyncef(self.init_serial())
            await asyncio.sleep(1)

    async def send(self, msg):
        if self.uart['alive'] != 1:
            await asyncio.sleep(2)
        if self.uart['alive'] == 1:
            length_msg = str(len(msg))
            bytearr = struct.pack('!B4s2s', self.header[0],
                    str.encode(self.header[1]), str.encode(length_msg))
            bytearr += struct.pack(f'!{length_msg}s', str.encode(msg))
            LOG_SEND.debug(f'ch{self.channel} : [{msg}]')
            self.uart['w'].write(bytearr + b'\n')

async def main():
    uart = Uart()
    task = await asyncio.ensure_future(uart.init_serial())
    await uart.send('hello123')
    await asyncio.sleep(10)

if __name__ == "__main__":
    asyncio.run(main())
